Contato realizado pelo site! Seguem os dados abaixo:
<br><br><br>

Nome: {{ $nome }}<br>
Email: {{ $email }}<br>
Telefone: {{ $telefone }}<br>
Assunto: {{ $assunto }}<br>
Mensagem: {{ $mensagem }}<br>