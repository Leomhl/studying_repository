php -S localhost:8000 -t public &
open http://localhost:8000

